var express = require("express");
var app =express();
var request = require("request");
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");


var campgrounds =[
		{name: "Salmon Bay", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSW-hY-LNZvOAnmgFLIvndxeZa94meRn70KlK79fCPOufKTosE_&s"},
		{name: "Salmon Hut", image: "https://www.nps.gov/shen/planyourvisit/images/20170712_A7A9022_nl_Campsites_BMCG_960.jpg?maxwidth=1200&maxheight=1200&autorotate=false"},
		{name: "Salmon Beach", image: "https://www.yosemite.com/wp-content/uploads/2016/04/westlake-campground.png"},
		{name: "Salmon Beach", image: "https://www.nps.gov/mora/planyourvisit/images/OhanaCampground2016_CMeleedy_01_web.jpeg?maxwidth=1200&maxheight=1200&autorotate=false"},
		
	]

app.post("/campgrounds", function(req, res){
	
//get a data form and add to campgrounds array
	var name= req.body.name
	var image= req.body.image
	var newCampground = {name: name, image:image}
	campgrounds.push(newCampground)
//redirect back to campgrounds page
	res.redirect("/campgrounds")
})


app.get("/", function(req, res){
	res.render("landing")
})

app.get("/campgrounds", function(req, res){
	 
	res.render("campgrounds", {campgrounds: campgrounds})
});

app.get("/campgrounds/new", function(req, res){
	res.render("new")
	console.log("hey!")
});

app.listen(3000, function(req, res){
	console.log("It Works!")
})