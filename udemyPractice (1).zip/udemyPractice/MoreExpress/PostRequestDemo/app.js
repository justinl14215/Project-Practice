var express = require("express");
var app = express();
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}))
app.set("view engine", "ejs");

var friends = ["Tina", "Jay","Kiesha", "Leroy"]

app.get("/", function(req, res) {
	res.render("home");
});
app.post("/afriend", function(req, res) {
	var newFriend = req.body.newFriend;
	
	friends.push(newFriend);
	res.redirect("/friends");
});
//friends list
app.get("/friends", function(req, res) {
	
	res.render("friends", {friends: friends});
})
app.listen(3000, function(){
	console.log("It works!")
})