var echo = "Heyy "
var name = "Ms.Parker!"
for(var i = 0;i <10; i++){
	console.log(echo  + name);
}