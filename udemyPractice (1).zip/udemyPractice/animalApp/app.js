var express = require("express")
var app = express()

app.get("/", function(req, res){
	res.send("Hello there, welcome to my animal app!");	
})
app.get("/says/:animal", function(req, res){
	var sounds = {
		dog: "bark bark",
		cat: "Meow",
		snake: "SSSS",
		bird: "chirp chirp"
	}
	var animals = req.params.animal;
	var sound = sounds[animals];

	
	
	res.send("The "+ animals.toUpperCase()+ " says '"+ sound +"'.")

})
app.get("/repeat/:word/:num", function(req, res){
 	var words = req.params.word;
	var number = Number(req.params.num);
	var solution = "";
	for( var i =0; i <number; i++){
		solution += words + " ";
	}
	res.send(solution)
})



app.listen(3000, function() { 
  console.log('Server listening on port 3000'); 
});
app.get("/*", function(req, res){
	res.send("Hello there, let's get back to good pages");	
})
