var express= require ("express")
var app = express()
app.get("/bowl", function(req, res){
	res.send("Spicy Ramen Podcast");
	
})
// "/" => "Hi there!"
app.get("/", function(req, res){
	res.send("Hi there!");
});

// "/bye" => "Goodbye!"
app.get("/bye", function(req, res){
	res.send("GoodBye!");
})
// "/bowl" => "Ramen"

app.get("*", function(req, res){
	res.send("NOPE!!!!");
})
app.listen(3000, function() { 
  console.log('Server listening on port 3000'); 
});