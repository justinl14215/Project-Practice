var express = require("express");
var app = express();
app.use(express.static("Assets"));
app.set("view engine", "ejs")

app.get("/", function(req, res){
	res.render("home");
	
})
app.get("/fallinlove/:thing", function(req, res){
	var thing= req.params.thing;
	res.render("love", {thingsVar: thing})
})
app.get("/posts", function(req, res){
	var posts = [
		{title: "Post 1", author: "Susy"},
		{title:"My adorable adorable life.", author: "Charlie"},
		{title:"Can you build a snowman?", author:"Justin"} 
	];
	res.render("post", {posts: posts})
})

app.listen(3000, function(){
	console.log("It Works!")
})